import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, useNavigate } from 'react-router-dom';
import { getParcelById, updateParcel, resetParcelState } from './parcelSlice';
import { fetchUsers } from '../users/userSlice'; // Import fetchUsers thunk

function EditParcel() {
  const { user } = useSelector((state) => state.auth); // Get user from auth state
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { parcel, isLoading, isError, message } = useSelector((state) => state.parcels);

  const [formData, setFormData] = useState({
    pickupAddress: '',
    deliveryAddress: '',
    size: '',
    type: '',
    paymentMethod: '',
    status: '',
    pickupLocation: {
      latitude: '',
      longitude: '',
    },
    deliveryLocation: {
      latitude: '',
      longitude: '',
    },
    assignedAgent: '', // Add assignedAgent to formData
  });

useEffect(() => {
  if (isError) {
    console.error(message);
  }

  dispatch(getParcelById(id));

  // Fetch delivery agents if user is admin
  if (user && user.role === 'Admin') {
    dispatch(fetchUsers('Delivery Agent'));
  }

  return () => {
    dispatch(resetParcelState());
  };
}, [id, isError, message, dispatch, user]);

  useEffect(() => {
    if (parcel) {
      const pickupLat = parcel.pickupLocation?.latitude || '';
      const pickupLng = parcel.pickupLocation?.longitude || '';
      const deliveryLat = parcel.deliveryLocation?.latitude || '';
      const deliveryLng = parcel.deliveryLocation?.longitude || '';

      // Check if coordinates are valid numbers before setting
      const validPickupLat = typeof pickupLat === 'number' ? pickupLat : '';
      const validPickupLng = typeof pickupLng === 'number' ? pickupLng : '';
      setFormData({
        pickupAddress: parcel.pickupAddress || '',
        deliveryAddress: parcel.deliveryAddress || '',
        size: parcel.size || '',
        type: parcel.type || '',
        paymentMethod: parcel.paymentMethod || '',
        status: parcel.status || '',
        pickupLocation: {
          latitude: validPickupLat,
          longitude: validPickupLng,
        },
        deliveryLocation: {
          latitude: typeof deliveryLat === 'number' ? deliveryLat : '',
          longitude: typeof deliveryLng === 'number' ? deliveryLng : '',
        },
        assignedAgent: parcel.assignedAgent?._id || '',
      });
    }
  }, [parcel]);

  const { pickupAddress, deliveryAddress, size, type, paymentMethod, status, pickupLocation, deliveryLocation, assignedAgent } = formData;
  const { users: deliveryAgents, isLoading: usersLoading, isError: usersError } = useSelector((state) => state.users);

  const onChange = (e) => {
    setFormData((prevState) => ({
      ...prevState,
      [e.target.name]: e.target.name === 'pickupLocation' || e.target.name === 'deliveryLocation'
        ? {
            ...prevState[e.target.name],
            [e.target.id]: parseFloat(e.target.value) || '',
          }
        : e.target.value,
    }));
  };

  const onSubmit = (e) => {
    e.preventDefault();

    // Filter out empty strings or non-numeric values for coordinates
    const filteredPickupLocation = {
      latitude: parseFloat(pickupLocation.latitude),
      longitude: parseFloat(pickupLocation.longitude),
    };
    const filteredDeliveryLocation = {
      latitude: parseFloat(deliveryLocation.latitude),
      longitude: parseFloat(deliveryLocation.longitude),
    };

    // Only include assignedAgent in formData if the user is admin
    const parcelData = user && user.role === 'Admin'
      ? { ...formData, pickupLocation: filteredPickupLocation, deliveryLocation: filteredDeliveryLocation }
      : { ...formData, assignedAgent: undefined, pickupLocation: filteredPickupLocation, deliveryLocation: filteredDeliveryLocation };

    dispatch(updateParcel({ id, parcelData }));
    // Navigate after successful update (optional: add success check)
    navigate(`/parcels/${id}`);
  };

  if (isLoading) {
    return <h2>Loading...</h2>;
  }

  if (!parcel) {
    return <h2>Parcel not found</h2>;
  }

  return (
    <div>
      <h2>Edit Parcel</h2>
      <form onSubmit={onSubmit}>
        <div>
          <label>Pickup Address:</label>
          <input
            type="text"
            name="pickupAddress"
            value={pickupAddress}
            onChange={onChange}
            required
          />
        </div>
        <div>
          <label>Delivery Address:</label>
          <input
            type="text"
            name="deliveryAddress"
            value={deliveryAddress}
            onChange={onChange}
            required
          />
        </div>
        <div>
          <label>Recipient Name:</label>
          <input
            type="text"
            name="recipientName"
            value={recipientName}
            onChange={onChange}
            required
          />
        </div>
        <div>
          <label>Recipient Phone:</label>
          <input
            type="tel"
            name="recipientPhone"
            value={recipientPhone}
            onChange={onChange}
            required
          />
        </div>
        <div>
          <label>Size:</label>
          <input
            type="text"
            name="size"
            value={size}
            onChange={onChange}
            required
          />
        </div>
        <div>
          <label>Type:</label>
          <input
            type="text"
            name="type"
            value={type}
            onChange={onChange}
            required
          />
        </div>
        <div>
          <label>Payment Method:</label>
          <select name="paymentMethod" value={paymentMethod} onChange={onChange} required>
            <option value="">Select Method</option>
            <option value="COD">COD</option>
            <option value="prepaid">Prepaid</option>
          </select>
        </div>
        <div>
          <label>Status:</label>
          <select name="status" value={status} onChange={onChange} required>
            <option value="Pending">Pending</option>
            <option value="Picked Up">Picked Up</option>
            <option value="In Transit">In Transit</option>
            <option value="Delivered">Delivered</option>
            <option value="Failed">Failed</option>
          </select>
        </div>
        <div>
          <label>Pickup Location (Lat, Lng):</label>
          <input
            type="text"
            name="pickupLocation"
            id="latitude"
            value={pickupLocation.latitude}
            onChange={onChange}
            placeholder="Latitude"
          />
          <input
            type="text"
            name="pickupLocation"
            id="longitude"
            value={pickupLocation.longitude}
            onChange={onChange}
            placeholder="Longitude"
          />
        </div>
        <div>
          <label>Delivery Location (Lat, Lng):</label>
          <input
            type="text"
            name="deliveryLocation"
            id="latitude"
            value={deliveryLocation.latitude}
            onChange={onChange}
            placeholder="Latitude"
          />
          <input
            type="text"
            name="deliveryLocation"
            id="longitude"
            value={deliveryLocation.longitude}
            onChange={onChange}
            placeholder="Longitude"
          />
        </div>
        {user && user.role === 'Admin' && (
          <div>
            <label>Assign Agent:</label>
            <select name="assignedAgent" value={assignedAgent} onChange={onChange}>
              <option value="">Select Agent</option>
              {deliveryAgents.map((agent) => (
                <option key={agent._id} value={agent._id}>
                  {agent.username} ({agent.email})
                </option>
              ))}
            </select>
          </div>
        )}
        <button type="submit">Update Parcel</button>
      </form>
    </div>
  );
}

export default EditParcel;