const express = require('express');
const router = express.Router();

const { protect, isAdmin } = require('../middleware/authMiddleware'); // <-- add this

const {
    getAllParcels,
    getParcelById,
    createParcel,
    updateParcel,
    deleteParcel,
    updateParcelStatus,
    generateParcelQRCode,
    trackParcel,
    getOptimizedRoute,
    generateParcelLabel
} = require('../controllers/parcelController');

router.route('/').get(protect, getAllParcels).post(protect, createParcel);
router.route('/track/:trackingNumber').get(trackParcel); // Public route for tracking
router.route('/route/:agentId').get(protect, getOptimizedRoute);
router.route('/:id').get(protect, getParcelById).put(protect, updateParcel).delete(protect, deleteParcel);
router.route('/:id/status').put(protect, updateParcelStatus);
router.route('/:id/qrcode').get(protect, generateParcelQRCode);
router.route('/:id/label').get(protect, generateParcelLabel);

module.exports = router;
