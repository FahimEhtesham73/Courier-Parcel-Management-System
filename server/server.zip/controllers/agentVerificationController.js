const AgentVerification = require('../models/AgentVerification');
const User = require('../models/User');
const asyncHandler = require('express-async-handler');
const { sendAgentVerificationNotification } = require('../utils/notifications');

// @desc    Submit agent verification documents
// @route   POST /api/agent-verification/submit
// @access  Private (Delivery Agent only)
const submitVerification = asyncHandler(async (req, res) => {
  // Check if user is a delivery agent
  if (req.user.role !== 'Delivery Agent') {
    res.status(403);
    throw new Error('Only delivery agents can submit verification documents');
  }

  // Check if verification already exists
  const existingVerification = await AgentVerification.findOne({ agent: req.user._id });
  if (existingVerification) {
    res.status(400);
    throw new Error('Verification documents already submitted');
  }

  const {
    documents,
    personalInfo
  } = req.body;

  // Validate required fields
  if (!documents.nidFront || !documents.nidBack || !documents.photo) {
    res.status(400);
    throw new Error('NID front, back, and photo are required');
  }

  if (!personalInfo.fullName || !personalInfo.nidNumber || !personalInfo.address) {
    res.status(400);
    throw new Error('Full name, NID number, and address are required');
  }

  const verification = await AgentVerification.create({
    agent: req.user._id,
    documents,
    personalInfo,
    status: 'Pending'
  });

  // Notify admins about new verification request
  try {
    const admins = await User.find({ role: 'Admin' });
    for (const admin of admins) {
      await sendAgentVerificationNotification(admin, req.user, 'submitted');
    }
  } catch (error) {
    console.error('Error sending admin notification:', error);
  }

  res.status(201).json({
    message: 'Verification documents submitted successfully',
    verification: {
      _id: verification._id,
      status: verification.status,
      submittedAt: verification.submittedAt
    }
  });
});

// @desc    Get agent's verification status
// @route   GET /api/agent-verification/status
// @access  Private (Delivery Agent only)
const getAgentVerification = asyncHandler(async (req, res) => {
  if (req.user.role !== 'Delivery Agent') {
    res.status(403);
    throw new Error('Only delivery agents can check verification status');
  }

  const verification = await AgentVerification.findOne({ agent: req.user._id })
    .populate('reviewedBy', 'username email');

  if (!verification) {
    return res.status(404).json({
      message: 'No verification documents found',
      hasSubmitted: false
    });
  }

  res.json({
    hasSubmitted: true,
    verification: {
      _id: verification._id,
      status: verification.status,
      submittedAt: verification.submittedAt,
      reviewedAt: verification.reviewedAt,
      reviewedBy: verification.reviewedBy,
      rejectionReason: verification.rejectionReason
    }
  });
});

// @desc    Get all verification requests
// @route   GET /api/agent-verification/all
// @access  Private (Admin only)
const getAllVerifications = asyncHandler(async (req, res) => {
  const { status } = req.query;
  let filter = {};
  
  if (status) {
    filter.status = status;
  }

  const verifications = await AgentVerification.find(filter)
    .populate('agent', 'username email phone')
    .populate('reviewedBy', 'username email')
    .sort({ submittedAt: -1 });

  res.json(verifications);
});

// @desc    Review verification request
// @route   PUT /api/agent-verification/review/:id
// @access  Private (Admin only)
const reviewVerification = asyncHandler(async (req, res) => {
  const { status, rejectionReason } = req.body;

  if (!['Approved', 'Rejected'].includes(status)) {
    res.status(400);
    throw new Error('Status must be either Approved or Rejected');
  }

  if (status === 'Rejected' && !rejectionReason) {
    res.status(400);
    throw new Error('Rejection reason is required when rejecting');
  }

  const verification = await AgentVerification.findById(req.params.id)
    .populate('agent', 'username email');

  if (!verification) {
    res.status(404);
    throw new Error('Verification request not found');
  }

  if (verification.status !== 'Pending') {
    res.status(400);
    throw new Error('This verification request has already been reviewed');
  }

  verification.status = status;
  verification.reviewedBy = req.user._id;
  verification.reviewedAt = new Date();
  
  if (status === 'Rejected') {
    verification.rejectionReason = rejectionReason;
  }

  await verification.save();

  // Update agent's verification status in User model
  await User.findByIdAndUpdate(verification.agent._id, {
    isVerified: status === 'Approved'
  });

  // Notify agent about the decision
  try {
    await sendAgentVerificationNotification(verification.agent, req.user, status.toLowerCase());
  } catch (error) {
    console.error('Error sending agent notification:', error);
  }

  // Emit Socket.IO event
  if (req.app.get('socketio')) {
    req.app.get('socketio').emit('verificationReviewed', {
      agentId: verification.agent._id,
      status: status,
      reviewedBy: req.user.username
    });
  }

  res.json({
    message: `Verification ${status.toLowerCase()} successfully`,
    verification
  });
});

module.exports = {
  submitVerification,
  getAgentVerification,
  getAllVerifications,
  reviewVerification
};