const express = require('express');
const mongoose = require('mongoose');
const http = require('http');
const { Server } = require('socket.io');
const dotenv = require('dotenv');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const parcelRoutes = require('./routes/parcel');
const userRoutes = require('./routes/user'); // Assuming user routes exist
const adminRoutes = require('./routes/admin');
const agentVerificationRoutes = require('./routes/agentVerification');
const { errorHandler } = require('./middleware/errorMiddleware');
const { protect } = require('./middleware/authMiddleware');

dotenv.config(); // Load environment variables

const app = express();
const port = process.env.PORT || 5000;
const mongoURI = process.env.MONGO_URI;
const server = http.createServer(app);
const io = new Server(server, {
  cors: { 
    origin: 'http://localhost:5173',
    credentials: true
  },
});

// Make io available to routes
app.set('socketio', io);

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));
app.use(cors({
  origin: 'http://localhost:5173', // Vite dev server
  credentials: true
}));

// Database connection
if (!mongoURI) {
  console.error('❌ MongoDB connection URI is not provided! Please set MONGO_URI in your .env file.');
  process.exit(1);
}

mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('✅ MongoDB connected'))
  .catch((err) => console.error('❌ MongoDB connection error:', err));

mongoose.connection.on('error', (err) => {
  console.error('MongoDB runtime error:', err);
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/parcels', protect, parcelRoutes);
app.use('/api/users', protect, userRoutes);
app.use('/api/admin', protect, adminRoutes);
app.use('/api/agent-verification', agentVerificationRoutes);

// Basic route
app.get('/', (req, res) => {
  res.send('Courier and Parcel Management System Backend');
});

// Socket.IO connection
io.on('connection', (socket) => {
  console.log('🔌 A user connected');

  socket.on('disconnect', () => {
    console.log('❌ User disconnected');
  });

  socket.on('error', (err) => {
    console.error('Socket.IO error:', err);
  });
});

// Error handling middleware
app.use(errorHandler);

// Start server
server.listen(port, () => {
  console.log(`🚀 Server running on port ${port}`);
});
